from regis import *

@bot.on(events.NewMessage(pattern=r"(?:.regis|/regis|/start)$"))
@bot.on(events.CallbackQuery(data=b'menu'))
async def menu(event):
	inline = [
[Button.inline(" REGISTER ","registrasi"),
Button.inline(" DELETE ","deleteip")],
[Button.inline(" RENEW IP ","perpanjang"),
Button.inline(" LIST IP ","cekallip")],
[Button.inline(" DOMAIN ","domain")]]
	sender = await event.get_sender()
	val = valid(str(sender.id))
	if val == "false":
		try:
			await event.answer("Akses Ditolak", alert=True)
		except:
			await event.reply("Akses Ditolak")
	elif val == "true":
		sh = f' curl -sS https://raw.githubusercontent.com/SETANTAZVPN/acs/main/ip | grep "###" | wc -l'
		ssh = subprocess.check_output(sh, shell=True).decode("ascii")

		msg = f"""
**◇ ━━━━━━━━━━━━━  ◇**
**◇☘️ADMIN AUTOSCRIPT☘️◇**
**◇ ━━━━━━━━━━━━━  ◇**
Halo Tuan {sender.first_name}

**» List Harga Sewa Panel :** 
🌸**1 BULAN 80k**
🍃**2 BULAN 120k**
🌻**3 BULAN 150K**
🐥**LIFE TIME 500K🐥**

**» Order :** @SilaaVp
**◇ ━━━━━━━━━━━━━  ◇**
**Total Pelanggan :** `{ssh.strip()}`
"""
		x = await event.edit(msg,buttons=inline)
		if not x:
			await event.reply(msg,buttons=inline)




















